cd trce_src
make clean
make
make clean
cd ../as_src
make clean
make
make clean
cd ..
ls bin
