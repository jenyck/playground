#include <stdio.h>                           // a PREPROCESSOR directive

int main()                                    // function header
{                                             // start of function body
    printf("Come up and C++ me some time.");  // message
    printf("\n");                             // start a new line
    printf("You won't regret it!");   // more output
// If the output window closes before you can read it,
// add the following code:
    return 0;                                 // terminate main()
}                                             // end of function body
